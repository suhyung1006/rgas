# 환급형 목표달성 서비스 (Refunds Goal Achivement Service)
참여자 :유상진, 이수형

최신 버전 : Branch = new_template

##### < 주의 사항 >
email.properties 필요

gmailid=구글 이메일 아이디<br>
gmailpassword=구글 이메일 비밀번호