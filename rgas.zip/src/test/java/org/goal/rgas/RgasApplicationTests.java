package org.goal.rgas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RgasApplicationTests {

	@Test
	void contextLoads() {
	}

}
