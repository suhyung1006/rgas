package org.goal.rgas.emailcertification;

public interface EmailCertificationService {
	public String certifiedCodeSend(String email, String code);
}